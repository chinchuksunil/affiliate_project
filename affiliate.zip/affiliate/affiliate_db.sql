-- phpMyAdmin SQL Dump
-- version 5.2.3-1.el9
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 25, 2025 at 08:29 AM
-- Server version: 8.0.44
-- PHP Version: 8.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `affiliate_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `commissions`
--

CREATE TABLE `commissions` (
  `id` int NOT NULL,
  `sale_id` int NOT NULL,
  `user_id` int NOT NULL,
  `level` int NOT NULL,
  `amount` float DEFAULT '0',
  `percentage` float NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `commissions`
--

INSERT INTO `commissions` (`id`, `sale_id`, `user_id`, `level`, `amount`, `percentage`, `created_at`) VALUES
(51, 44, 16, 1, 500.045, 0.1, '2025-11-25 11:37:18'),
(52, 44, 15, 2, 250.023, 0.05, '2025-11-25 11:37:18'),
(53, 44, 14, 3, 150.014, 0.03, '2025-11-25 11:37:18'),
(54, 44, 13, 4, 100.009, 0.02, '2025-11-25 11:37:18'),
(55, 44, 11, 5, 50.0045, 0.01, '2025-11-25 11:37:18'),
(56, 45, 8, 1, 200, 0.1, '2025-11-25 11:55:49'),
(57, 47, 17, 1, 400, 0.1, '2025-11-25 11:59:19'),
(58, 47, 16, 2, 200, 0.05, '2025-11-25 11:59:19'),
(59, 47, 15, 3, 120, 0.03, '2025-11-25 11:59:19'),
(60, 47, 14, 4, 80, 0.02, '2025-11-25 11:59:19'),
(61, 47, 13, 5, 40, 0.01, '2025-11-25 11:59:19'),
(62, 48, 11, 1, 40, 0.1, '2025-11-25 12:04:52'),
(63, 48, 9, 2, 20, 0.05, '2025-11-25 12:04:52'),
(64, 48, 8, 3, 12, 0.03, '2025-11-25 12:04:52'),
(65, 49, 16, 1, 10, 0.1, '2025-11-25 12:09:57'),
(66, 49, 15, 2, 5, 0.05, '2025-11-25 12:09:57'),
(67, 49, 14, 3, 3, 0.03, '2025-11-25 12:09:57'),
(68, 49, 13, 4, 2, 0.02, '2025-11-25 12:09:57'),
(69, 49, 11, 5, 1, 0.01, '2025-11-25 12:09:57');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `amount` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `currency` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'INR',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `user_id`, `amount`, `currency`, `created_at`) VALUES
(44, 17, '5000.45', 'INR', '2025-11-25 06:07:18'),
(45, 9, '2000', 'INR', '2025-11-25 06:25:49'),
(46, 8, '10000', 'INR', '2025-11-25 06:26:27'),
(47, 19, '4000', 'INR', '2025-11-25 06:29:19'),
(48, 13, '400', 'INR', '2025-11-25 06:34:52'),
(49, 17, '100', 'INR', '2025-11-25 06:39:57');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `parent_id` bigint NOT NULL,
  `extras` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `parent_id`, `extras`, `created_at`) VALUES
(8, 'chinchu', 'chinchu@gmail.com', NULL, 0, '', '2025-11-25 04:36:02'),
(9, 'Heera', 'heera@gmail.com', NULL, 8, '', '2025-11-25 04:52:09'),
(10, 'santhi', 'santhi@gmail.com', NULL, 8, '', '2025-11-25 05:06:30'),
(11, 'sunil', 'sunil@gmail.com', NULL, 9, '', '2025-11-25 05:11:12'),
(12, 'suman', 'suman@gmail.com', NULL, 9, '', '2025-11-25 05:11:39'),
(13, 'supru', 'supru@gmail.com', NULL, 11, '', '2025-11-25 05:12:11'),
(14, 'Asha', 'asha@gmail.com', NULL, 13, '', '2025-11-25 05:12:35'),
(15, 'Anu', 'anu@gmail.com', NULL, 14, '', '2025-11-25 05:13:57'),
(16, 'leela', 'leela@gmail.com', NULL, 15, '', '2025-11-25 05:14:50'),
(17, 'aju', 'aju@gmail.com', NULL, 16, '', '2025-11-25 05:18:17'),
(18, 'reshma', 'reshu@gmail.com', NULL, 12, '', '2025-11-25 05:23:49'),
(19, 'lucky', 'lucky@gmail.com', NULL, 17, '', '2025-11-25 06:28:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `commissions`
--
ALTER TABLE `commissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `commissions`
--
ALTER TABLE `commissions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
